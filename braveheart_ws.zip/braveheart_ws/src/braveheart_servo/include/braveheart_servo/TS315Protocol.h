#ifndef TS315PROTOCOL
#define TS315PROTOCOL

#include "braveheart_servo/servo_common.h"

//机械臂通讯库
class TS315Protocol
{
public:
	TS315Protocol();
	~TS315Protocol();

	//读取某个舵机的脉宽  返回是否成功
	bool readPulseWidth(Serial & sp, int joint_id, int & value);

	//读取某个舵机的角度  返回是否成功
	bool readAngle(Serial & sp, int joint_id, double & value);

	//写某个舵机的脉宽(角度)  返回是否成功。  参数: 串口实例  舵机号  脉宽  时间 
	int writePulseWidth(Serial & sp, int joint_id, int puls_width, int duration );

	int writeAngle(Serial & sp, int joint_id, double angle, int duration );

	//写多个舵机的脉宽(角度)  返回是否成功    参数: 串口实例  数组长度  舵机号组  脉宽组  时间 
	int writeMulPulseWidth(Serial & sp, int count, int* joint_id, int* puls_width, int duration );
	
	//写多个舵机的脉宽(角度)  返回是否成功    参数: 串口实例  数组长度  舵机号组  角度组  时间 
	int writeMulAngle(Serial & sp, int count, int* joint_id, double* angles, int duration );
	
private:
	//缓存数组最大长度
	const int bufferSize;

	//发送缓存
	uint8_t * txBuffer;

	//接收缓存
	uint8_t * rxBuffer;

	//记录缓存区中已用的位数
	int KeyRX;
	int KeyTX;

	//清理缓存
	void flushTxBuffer();
	void flushRxBuffer();
	void flush();

};

#endif // TS315PROTOCOL