#include "braveheart_servo/TS315Protocol.h"


using namespace std; 

//读取单片机的状态并发布出来

class servo_tf
{
    public:
        servo_tf()
        {   
            //私有参数 获取
            ros::NodeHandle nh_private("~");
            nh_private.param<string>("serialport_name", serialport_name, "/dev/ts315");
            nh_private.param<int>("baudrate", baudrate, 9600);

            //串口初始化
            Timeout timeout = Timeout::simpleTimeout(1000);
            try
            {
                serialPort = new Serial(serialport_name, baudrate, timeout);
            }
            catch (exception e)
            {
                cout << "SerialPort Opened failed" << endl;
                exit(0);
            }
            //检查串口是否正常
            if(serialPort->isOpen()){cout << "SerialPort isOpen." << endl;}
            else{cout << "SerialPort Opened failed" << endl;return;}

            //通信协议初始化
            protocol = new TS315Protocol();
            serialPort->flush ();

            //发布者
            joint_pub_ = nh_.advertise<sensor_msgs::JointState>("joint_states", 1);
            joint_sub_ = nh_.subscribe("/image_adapt_servo", 1, &servo_tf::callback, this);
            
            joint_state_msg.name.resize(1);
            joint_state_msg.position.resize(1);
            joint_state_msg.velocity.resize(1);
            joint_state_msg.effort.resize(1);

            joint_state_msg.header.frame_id = "joint_1";
            joint_state_msg.name[0]="joint_1";
            joint_state_msg.position[0] = 0.0;
            joint_state_msg.velocity[0] = 0.0;
            joint_state_msg.effort[0] = 0.0;            
        }

        void start()
        {
            while (ros::ok()) 
            {   
                //默认一号舵机
                if(protocol->readAngle(*serialPort, 1, readAngle))
                {
                    joint_state_msg.header.stamp = ros::Time::now();
                    joint_state_msg.position[0] = readAngle;
                    joint_pub_.publish(joint_state_msg); 
                    loop_rate.sleep();
                    ros::spinOnce();
                }
            }
        }

        void callback(const sensor_msgs::JointState::ConstPtr& msg)
        {
            //写入角度
            protocol->writeAngle( *serialPort, 1, msg->position[0], 100 );
        }


    private:
        ros::NodeHandle nh_;
        ros::Publisher joint_pub_;
        ros::Subscriber joint_sub_;
        
        ros::Rate loop_rate = ros::Rate(10);

        sensor_msgs::JointState joint_state_msg;

        //串口交互
        Serial * serialPort;
        string serialport_name;
        int baudrate;

        //协议
        TS315Protocol * protocol;

        //读出的角度
        double readAngle;
};


int main(int argc, char** argv) 
{ 
    ros::init(argc, argv, "servo_joint_publisher");

    servo_tf a_tf = servo_tf();

    a_tf.start();

    return 0; 
}