#include "braveheart_base/BraveheartMotor.h"


int main(int argc, char *argv[])
{   
    ros::init(argc, argv, "arduino_due_node");
    BraveheartMotor braveheart_motor = BraveheartMotor();
    return 0;
}