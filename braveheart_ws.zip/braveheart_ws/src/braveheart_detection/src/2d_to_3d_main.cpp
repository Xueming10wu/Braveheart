#include "braveheart_detection/Measurement.h"

int main(int argc, char *argv[])
{
    ros::init(argc, argv, "2d_to_3d_node");
    Measurement measurement = Measurement();
    return 0;
}