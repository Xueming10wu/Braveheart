#include "braveheart_detection/Measurement.h"

Measurement::Measurement()
{
    //私有参数 获取
    ros::NodeHandle nh_private("~");
    nh_private.param<int>("/camera/left_focal", left_focal, 1400);
    nh_private.param<int>("/camera/right_focal", right_focal, 1400);
    nh_private.param<double>("/camera/base_line", base_line, 0.20);
    nh_private.param<int>("/camera/image/width" , image_width, 1280);
    nh_private.param<int>("/camera/image/height", image_height, 720);

	//ros交互
    publisher = nh.advertise<braveheart_detection::ObjectoryImageSizePosition>("/detect/real_position", 1);
    l_subscriber = nh.subscribe("/detect/left/ImagePosition", 1, &Measurement::leftCallBack, this);
    r_subscriber = nh.subscribe("/detect/right/ImagePosition", 1, &Measurement::rightCallBack, this);

	//回调函数标志位
	l_flage = false;
    r_flage = false;
    
    ros::Rate loop_rate(10);
    while (ros::ok())
    {   
        if (l_flage && r_flage)
        {
            publishMsg();
        }
        
        ros::spinOnce();
        loop_rate.sleep();
    }

    ros::spin();
}

Measurement::~Measurement()
{

}

//回调函数
void Measurement::leftCallBack(const braveheart_detection::ObjectoryImageSizePosition & msg)
{
    l_flage = true;
    l_msg = msg;
    /*
    l_msg.header = msg.header;
    l_msg.name = msg.name;
    l_msg.size = msg.size;
    l_msg.position = msg.position;
    */
}

void Measurement::rightCallBack(const braveheart_detection::ObjectoryImageSizePosition & msg)
{
    r_flage = true;
    r_msg = msg;
    /*
    r_msg.header = msg.header;
    r_msg.name = msg.name;
    r_msg.size = msg.size;
    r_msg.position = msg.position;
    */
}

//发布者发布函数
void Measurement::publishMsg()
{
    l_flage = false;
	r_flage = false;
    double secs = (r_msg.header.stamp - l_msg.header.stamp).toSec();

    if(l_msg.info.data == r_msg.info.data)
    {//左右图像是否检测到的是同一个物体
        if( fabs(secs) < 3)
        {//只有左右图像相差0.5s内的时候才能够确定实时性
            double delta =  l_msg.position.x - r_msg.position.x;

            //中心点位置计算
            double arg_z=left_focal * base_line / delta;
            cout<< "arg_z  " << arg_z <<endl;
            pub_msg.position.z = -0.0975*(arg_z*arg_z)+0.6661*arg_z + 0.013 - 0.05;
            //pub_msg.position.z = left_focal * base_line / delta;
            pub_msg.position.x = pub_msg.position.z * (l_msg.position.x - image_width / 2) / left_focal;
            pub_msg.position.y = pub_msg.position.z * (l_msg.position.y - image_height / 2) / left_focal;

            //左上角点位置计算
            delta = (l_msg.position.x - l_msg.size.wide / 2) - (r_msg.position.x - r_msg.size.wide / 2);
            upleft_z = left_focal * base_line / delta;
            upleft_x = upleft_z * (l_msg.position.x - (image_width + l_msg.size.wide) / 2 );
            upleft_y = upleft_z * (l_msg.position.y - (image_height + r_msg.size.height) / 2 );

            //右下角点位置计算
            delta = (l_msg.position.x + l_msg.size.wide / 2) - (r_msg.position.x + r_msg.size.wide / 2);
            downright_z = left_focal * base_line / delta;
            downright_x = downright_z * (l_msg.position.x - (image_width - l_msg.size.wide) / 2 );
            downright_y = downright_z * (l_msg.position.y - (image_height - r_msg.size.height) / 2 );

            //尺寸计算
            pub_msg.size.length = fabsf(upleft_z - downright_z);
            pub_msg.size.wide = fabsf(downright_x - upleft_x);
            pub_msg.size.height = fabsf(downright_y - upleft_y);
            
            //坐标系为左摄像头
            pub_msg.header.frame_id = l_msg.header.frame_id;

            //信息保存
            pub_msg.name = l_msg.name;
            pub_msg.info = l_msg.info;

            //时间戳
            pub_msg.header.stamp = ros::Time::now();
            
            //发送
            publisher.publish(pub_msg);
        }
        else
        {
            ROS_WARN("Measurement : Timeout");
        }
    }
    else
    {
        ROS_WARN("Not the same object name");
    }
}