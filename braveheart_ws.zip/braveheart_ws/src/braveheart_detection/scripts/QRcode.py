#!/usr/bin/env python
# -*- coding: utf-8 -*
import cv2
import pyzbar.pyzbar as pyzbar

def decodeDisplay(frame):
    barcodes = pyzbar.decode(frame)
    box = []

    for barcode in barcodes:
        # 提取二维码的边界框的位置
        # 画出图像中条形码的边界框
        (x, y, w, h) = barcode.rect
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
        #cv2.imshow("Frame",frame)
        # 提取二维码数据为字节对象，所以如果我们想在输出图像上
        # 画出来，就需要先将它转换成字符串
        barcodeData = barcode.data.decode("utf-8")
        box = [barcodeData,x,w,y,h]
        print box

        # 绘出图像上条形码的数据
        cv2.putText(frame, barcodeData, (x, y - 10),cv2.FONT_HERSHEY_SIMPLEX,1, (0, 255, 0), 3)
    return box
 
def detect(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    box = decodeDisplay(gray)
    return box
    
 
if __name__ == '__main__':
    detect(frame)
