#!/usr/bin/env python      
# -*- coding: utf-8 -*-
from __future__ import print_function

import sys
import cv2
import rospy
import time
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from braveheart_detection.msg import ObjectoryImageSizePosition
from QRcode import decodeDisplay, detect

class detectSth(object):
    
    def __init__(self, frame_prefix  ):
        sub_topic = "/camera/" + frame_prefix + "/image_raw"
        pub_topic = "/detect/" + frame_prefix + "/ImagePosition"
        #display_topic = "/detect/" + frame_prefix + "/dispaly"
        frame_id = frame_prefix + "_camera_link"
        self.__subscriber = rospy.Subscriber(sub_topic, Image, self.callback)
        self.__publisher = rospy.Publisher(pub_topic, ObjectoryImageSizePosition, queue_size=1)
        self.__pub_msg = ObjectoryImageSizePosition()
        self.__pub_msg.header.frame_id = frame_id
        self.__pub_msg.position.z = 0
        self.__pub_msg.size.length = 0
        self.__bridge = CvBridge()

        print("detectSth construced !")
        try:
            rospy.spin()
        except KeyboardInterrupt:
            print("Shutting down")
        
    def callback(self, data):
        try:
            cv_image = self.__bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            print(e)
        #cv2.imshow("cv_image", cv_image)
        #cv2.waitKey(3)
        (rows,cols,channels) = cv_image.shape
        #二维码处理，list1 二维码和二维码地址列表
        list1 = detect(cv_image)
        if len(list1) == 0:
            print(list1)
            print("未找到二维码")
        else:
            print("找到二维码")
            self.__pub_msg.name.data = "QTcode"
            self.__pub_msg.info.data = (list1[0])[0:2]
            self.__pub_msg.position.x = list1[1]
            self.__pub_msg.size.wide = list1[2]
            self.__pub_msg.position.y =list1[3] 
            self.__pub_msg.size.height = list1[4]
            self.__pub_msg.header.stamp = rospy.Time.now()
            self.publish()

    def publish(self):
        self.__publisher.publish(self.__pub_msg)

def main():
    rospy.init_node("2d_zibar_node", anonymous = False)

    frame_prefix = rospy.get_param("~camera_link_prefix", "")
    #print (frame_prefix)
    d = detectSth( frame_prefix )
    
if __name__ == '__main__':
    main()