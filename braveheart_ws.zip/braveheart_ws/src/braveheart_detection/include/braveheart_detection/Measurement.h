#ifndef MEASUREMENT
#define MEASUREMENT

#include "braveheart_detection/detection_common.h"

class Measurement
{
public:
	Measurement();
	virtual ~Measurement();

	//回调函数
	void leftCallBack(const braveheart_detection::ObjectoryImageSizePosition & msg);
	void rightCallBack(const braveheart_detection::ObjectoryImageSizePosition & msg);

	//发布者发布函数
	void publishMsg();


private:
	//ros交互
	ros::NodeHandle nh;
	ros::Publisher publisher;
    ros::Subscriber l_subscriber;
	ros::Subscriber r_subscriber;

	//ros消息
	braveheart_detection::ObjectoryImageSizePosition l_msg;
	braveheart_detection::ObjectoryImageSizePosition r_msg;
	braveheart_detection::ObjectoryRealSizePosition pub_msg;

	//回调函数标志位
	bool l_flage;
	bool r_flage;

	//焦距(像素点)
	int left_focal;
	int right_focal;

	//图像尺寸(像素点)
	int image_width;
	int image_height;

	//物体左上角坐标点
	float upleft_x;
	float upleft_y;
	float upleft_z;

	//物体右下角坐标点
	float downright_x;
	float downright_y;
	float downright_z;

	//基线长度(m)
	double base_line;

};

#endif // MEASUREMENT