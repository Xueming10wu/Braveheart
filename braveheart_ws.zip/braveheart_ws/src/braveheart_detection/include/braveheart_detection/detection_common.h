#ifndef DETECTION_COMMON
#define DETECTION_COMMON
//所以平时需要用到的头文件都放在这里
#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <unistd.h>
#include <typeinfo>
#include <inttypes.h>

#include <cmath>
#include <cstring>
#include <signal.h>
#include <vector>


//ros头文件
#include "ros/ros.h"
#include "braveheart_detection/ObjectoryImageSizePosition.h"
#include "braveheart_detection/ObjectoryRealSizePosition.h"


using namespace std;
using namespace braveheart_detection;


#endif // BASE_COMMON