#ifndef BAMBOOARMROBOT
#define BAMBOOARMROBOT

#include "bamboo_arm/arm_common.h"
#include "bamboo_arm/TS315Protocol.h"

//相当于MyRbot
class BambooArmRobot : public hardware_interface::RobotHW
{
public:
	BambooArmRobot();
	virtual ~BambooArmRobot();

  void read();
  void write();

  void graspCB(const std_msgs::UInt16ConstPtr & msg );

private:
  //ros交互
	ros::NodeHandle nh;
  ros::Subscriber grasp_sub;
  hardware_interface::JointStateInterface jnt_state_interface;
  hardware_interface::PositionJointInterface jnt_pos_interface;

	//串口交互
	Serial * serialPort;
	string serialport_name;
  int baudrate;

  //通讯协议对象
  TS315Protocol * protocolHandlePtr;

  //自由度
  const uint8_t joint_count;
  string * joint_name;
  double * cmd;
  double * pos;
  double * vel;
  double * eff;
};

#endif //BAMBOOARMROBOT
