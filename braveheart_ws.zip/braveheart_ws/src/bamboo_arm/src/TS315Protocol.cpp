#include "bamboo_arm/TS315Protocol.h"


//构造函数
TS315Protocol::TS315Protocol():bufferSize(1024)
{
    rxBuffer = new uint8_t[bufferSize];
    txBuffer = new uint8_t[bufferSize];
    rxBuffer[bufferSize - 1] = '\0';
    txBuffer[bufferSize - 1] = '\0';
    KeyRX = 0;
    KeyTX = 0;
    cout << "TS315Protocol construct" << endl;
}


//析构函数
TS315Protocol::~TS315Protocol()
{
    delete []txBuffer;
    delete []rxBuffer;
    txBuffer = NULL;
    rxBuffer = NULL;
}


//读取某个舵机的脉宽(角度)，返回0则是读取数据失败
bool TS315Protocol::readPulseWidth(Serial &serialport, int joint_id, int & value)
{
    /////////////////////////////////////请求数据消息的创建////////////////////////////////////////
    stringstream ss;

    //TS315
    //ss << "#" << joint_id << "PRAD!";
    
    ss << "#";
    int temp = 100;
    for (size_t i = 0; i < 3; i++)
    {
        ss << int(joint_id /temp);
        temp = temp / 10;
    }
    //ss << "PRAD\r\n";
    ss << "PRAD!";

    string txstring = ss.str();
    char *tx_char = (char *)txstring.c_str();
    KeyTX = strlen(tx_char);

    cout << "len " << KeyTX << " " << txstring << "  ";
    for (size_t i = 0; i < KeyTX; i++)
    {
         txBuffer[i] = (uint8_t)tx_char[i];
    }
    /////////////////////////////////////请求数据消息的创建完毕//////////////////////////////////////


    //////////////////////////////////////串口请求发送/////////////////////////////////////////////////
    int txnum = serialport.write(txBuffer, KeyTX);
    if (txnum != KeyTX)
    {
        cout << "readJoint write failed" << endl;
        return false;
    }
    else
    {
        cout << "readJoint write successed ! ";
    }

    //////////////////////////////////////串口请求发送完毕/////////////////////////////////////////////


    /////////////////////////////////////响应数据的接收//////////////////////////////////////////
    //固定位数为11位
    KeyRX = 11;

    //rx索引
    int key = 0;
    bool canRead = false;

    //循环超时次数 10ms/次
    int loop_count = 10;
    
    //确定型号
    int sort = -1;
    while(!canRead)
    {   
        //cout << "serialport.available()  " << serialport.available() << endl;
        //串口是否有数据
        if (sort == -1)
        {
            if (serialport.available() == 11)
            {//ts315
                sort = 0;
                cout << "\nts315   ";
            }
            else if( serialport.available() == 10)
            {//zxd380
                sort = 1;
                cout << "\nzxd380   ";
            }
            else
            {   
            }
        }
        
        if (sort == 0)
        {//ts315
            //数据读取
            rxBuffer[key] = (serialport.read(1).c_str())[0];
            //cout << "rxBuffer " << rxBuffer[key]  << "\n";
            key += 1;
            if (rxBuffer[0] != (uint8_t)'#')
            {   
                //丢包错误
                cout << "lost package:  #" << endl;
                key = 0;
                continue;
            }
            if (key < 11)
            {
                //正常执行时
                continue;
            }
            if (rxBuffer[9] != (uint8_t)'\r')
            {
                cout << "lost package:  \\r" << endl;
                key = 0;
                continue;
            }
            if (rxBuffer[10] != (uint8_t)'\n')
            {
                cout << "lost package:  \\n" << endl;
                key = 0;
                continue;
            }
            //通过检测，可以读取数据
            canRead = true;
        }
        else if(sort == 1)
        {//zxd380
            //数据读取
            rxBuffer[key] = (serialport.read(1).c_str())[0];
            //cout << "rxBuffer " << rxBuffer[key]  << "\n";
            key += 1;
            if (rxBuffer[0] != (uint8_t)'#')
            {   
                //丢包错误
                cout << "lost package:  #" << endl;
                key = 0;
                continue;
            }
            if (key < 10)
            {
                //正常执行时
                continue;
            }
            
            if (rxBuffer[9] != (uint8_t)'!')
            {
                cout << "lost package:  !" << endl;
                key = 0;
                continue;
            }
            
            //通过检测，可以读取数据
            canRead = true;
        }
        else
        {
            //等待数据
            if (loop_count <= 5)
            {   //超出读取次数
                cout << "Timeout duration in readPulseWidth or readAngle" << endl;
                return false;
            }
            loop_count --;
            usleep(10000);
            continue;
        }

    }
    /*
    cout << "RXBUFFER ";
    for (size_t i = 0; i < KeyRX; i++)
    {
        cout << int(rxBuffer[i]) << " ";
    }
    cout << "\n";
    */

    
    /////////////////////////////////////响应数据的接收完毕//////////////////////////////////////////



    /////////////////////////////////////响应数据的解码////////////////////////////////////////////

    //串口读出
    int res_joint_id = int((rxBuffer[1] - uint8_t('0'))* 100 
                    + (rxBuffer[2] - uint8_t('0')) * 10 
                    + (rxBuffer[3] - uint8_t('0')) * 1);
                    
    int res_position = int((rxBuffer[5] - uint8_t('0') )* 1000 
                    + (rxBuffer[6] - uint8_t('0') ) * 100 
                    + (rxBuffer[7] - uint8_t('0')) * 10 
                    + (rxBuffer[8] - uint8_t('0')) * 1);
    /////////////////////////////////////响应数据的解码完毕//////////////////////////////////////////

    if (res_joint_id == joint_id)
    {
        cout <<  "joint_id " << joint_id << ", res_position " << res_position <<  "\n\n";
        value = res_position;
        return true;
    }
    else
    {
        cout << "Read except joint is " << joint_id << " , but respond " << res_joint_id << " , position " << res_position << "\n\n";
    }
    
    return false;
}

//读取某个舵机的角度  返回是否成功
bool TS315Protocol::readAngle(Serial & serialport, int joint_id, double & value)
{
    int v;
    if (readPulseWidth(serialport, joint_id, v))
    {   
        value = double(v - 1500)  * PI * 270.0 / ((2500-500) * 180);
        return true;
    }
    else
    {
        return false;
    }
    return false;
}



//写某个舵机的脉宽(角度)  返回是否成功 成功:1  失败:0
int TS315Protocol::writePulseWidth( Serial &serialport, int joint_id, int puls_width, int duration )
{
    stringstream ss;

    ss << "#";
    int temp = 100;
    for (size_t j = 0; j < 3; j++)
    {
        
        ss << int((joint_id % (temp * 10)) /temp);
        temp = temp / 10;
    }
    ss << "P";
    temp = 1000;
    for (size_t j = 0; j < 4; j++)
    {
        ss << int((puls_width % (temp * 10)) /temp);
        temp = temp / 10;
    }

    ss << "T" << duration << "!" ;

    string txstring = ss.str();
    char *tx_char = (char *)txstring.c_str();
    KeyTX = strlen(tx_char);
    cout << "len " << KeyTX << " " << txstring << "  ";

    for (size_t i = 0; i < KeyTX; i++)
    {
         txBuffer[i] = (uint8_t)tx_char[i];
    }

    int txnum = serialport.write(txBuffer, KeyTX);
    if (txnum != KeyTX)
    {
        cout << "writeJoint write failed :" << endl;
        return 0;
    }
    else
    {
        cout << "writeJoint write success !" << endl;
    }
    return 1;
}


int TS315Protocol::writeAngle( Serial &serialport, int joint_id, double angle, int duration )
{
    //cout << "angle " << angle << endl;
    int puls_width = round((angle * 180 * (2500 - 500))/ (PI  * 270) + 1500);
    //cout << "writeAngle  " << puls_width << endl;
    return writePulseWidth( serialport, joint_id, puls_width, duration );
}



int TS315Protocol::writeMulPulseWidth(Serial & serialport, int count, int* joint_id, int* puls_width, int duration )
{
    stringstream ss;
    /*
    //TS315
    for (size_t i = 0; i < count; i++)
    {
        ss << "#" << joint_id[i] << "P" << puls_width[i];
    }
    */
    for (size_t i = 0; i < count; i++)
    {
        ss << "#";
        int temp = 100;
        for (size_t j = 0; j < 3; j++)
        {
            
            ss << int((joint_id[i] % (temp * 10)) /temp);
            temp = temp / 10;
        }
        ss << "P";
        temp = 1000;
        for (size_t j = 0; j < 4; j++)
        {
            ss << int((puls_width[i] % (temp * 10)) /temp);
            temp = temp / 10;
        }

        cout << "data :" << ss.str() << endl;
    }
    
    ss << "T" << duration << "!" ;
    string txstring = ss.str();

    char *tx_char = (char *)txstring.c_str();
    KeyTX = strlen(tx_char);
    cout << "len " << KeyTX << " " << txstring << endl;

    for (size_t i = 0; i < KeyTX; i++)
    {
         txBuffer[i] = (uint8_t)tx_char[i];
    }

    int txnum = serialport.write(txBuffer, KeyTX);
    if (txnum != KeyTX)
    {
        cout << "writeJoint write failed :" << endl;
        return 0;
    }
    else
    {
        cout << "writeJoint write success !" << endl;
    }
    return 1;
}

int TS315Protocol::writeMulAngle(Serial & serialport, int count, int* joint_id, double* angles, int duration )
{   
    int puls_width[count];
    for (size_t i = 0; i < count; i++)
    {
        puls_width[i] = round((angles[i] * 180 / PI) * ((2500 - 500) / 270) + 1500);
    }

    return writeMulPulseWidth(serialport, count, joint_id, puls_width, duration );
}


void TS315Protocol::flushTxBuffer()
{
    for (size_t i = 0; i < bufferSize - 1; i++)
    {
        txBuffer[i] = '$';
    }
    KeyTX = 0;
}

void TS315Protocol::flushRxBuffer()
{
    for (size_t i = 0; i < bufferSize - 1; i++)
    {
        rxBuffer[i] = '$';
    }
    KeyRX = 0;
}

void TS315Protocol::flush()
{
    flushTxBuffer();
    flushRxBuffer();
}