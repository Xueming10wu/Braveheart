#include "bamboo_arm/BambooArmRobot.h"



BambooArmRobot::BambooArmRobot() : joint_count(5)
{   
    //私有参数 获取
    ros::NodeHandle nh_private("~");
    nh_private.param<string>("serialport_name", serialport_name, "/dev/ttyUSB0");
    nh_private.param<int>("baudrate", baudrate, 115200);

    //初始化一些变量
    joint_name = new string[joint_count];
    
    cmd = new double[joint_count];
    pos = new double[joint_count];
    vel = new double[joint_count];
    eff = new double[joint_count];
    for (size_t i = 0; i < joint_count; i++)
    {
        cmd[i] = 0;
        pos[i] = 0;
        vel[i] = 0;
        eff[i] = 0;
    }
    


    stringstream ss;
    ss.clear();ss.str("");
    for (size_t i = 0; i < joint_count; i++)
    {
        ss << "joint_" << i + 1;
        joint_name[i] = ss.str();
        ss.clear();ss.str("");
    }

    for (size_t i = 0; i < joint_count; i++)
    {
        cout << joint_name[i] << endl;
    }

    //初始化串口
    Timeout timeout = Timeout::simpleTimeout(1000);
    try
    {
        serialPort = new Serial(serialport_name, baudrate, timeout);
        ROS_INFO("ARM SerialPort Opened successfully ! Serial: %s, %d", serialport_name.c_str(), baudrate );
    }
    catch (exception e)
    {
        //cout << "SerialPort Opened failed" << endl;
        ROS_ERROR("ARM SerialPort Opened failed! Serial: %s, %d", serialport_name.c_str(), baudrate );
        exit(0);
    }

    //初始化协议
    protocolHandlePtr = new TS315Protocol();

    //接收者初始化
    grasp_sub = nh.subscribe("/bamboo/grasp", 1, &BambooArmRobot::graspCB, this);
    

    //状态发布控制器  用于反馈机械臂实时状态
    vector<hardware_interface::JointStateHandle> state_handle;//添加关节
    for (size_t i = 0; i < joint_count; i ++)
    {
        state_handle.push_back( hardware_interface::JointStateHandle(joint_name[i], &pos[i], &vel[i], &eff[i]) );
        jnt_state_interface.registerHandle(state_handle[i]);
    }
    //控制器注册
    registerInterface(&jnt_state_interface);


    //位置控制器 用于发布机械臂需要移动到的位置
    std::vector<hardware_interface::JointHandle> pos_handle;//添加关节
    for (size_t i = 0; i < joint_count; i++)
    {
        pos_handle.push_back(hardware_interface::JointHandle(jnt_state_interface.getHandle(joint_name[i]), &cmd[i]));
        jnt_pos_interface.registerHandle(pos_handle[i]);
    }
    //控制器注册
    registerInterface(&jnt_pos_interface);
}

BambooArmRobot::~BambooArmRobot()
{
}

void BambooArmRobot::read()
{   
    //double readAngle(Serial & sp, int joint_id, doube &value);
    double temp;
    for (size_t i = 0; i < joint_count; i++)
    {
        if(protocolHandlePtr->readAngle( *serialPort, i + 1, temp))
        {
            if (i == 1)
            {
                temp = temp / 0.7812;
            }
            pos[i] = temp;

        }
        else
        {
            pos[i] = 0;
            cout << "BambooArmRobot::read : read one wrong angle \n";
        }
        usleep(10000);
    }
}



void BambooArmRobot::write()
{
    //int writeAngle(Serial & sp, int joint_id, double angle, int duration );
    double temp = 0;
    for (size_t i = 0; i < joint_count; i++)
    {
        temp = cmd[i];
        if (i == 1)
        {
            temp = temp * 0.7812;
        }
        
        cout << temp << " ";
        

        if(protocolHandlePtr->writeAngle( *serialPort, i + 1, temp, 500 ) == 0)
        {
            cout << "BambooArmRobot::write : ERROR int sending command\n";
        }
        usleep(10000);
        
    }
    cout << "\n ";
}


void BambooArmRobot::graspCB(const std_msgs::UInt16ConstPtr & msg )
{
    //抓手舵机编号
    if(protocolHandlePtr->writePulseWidth( *serialPort, 6, msg->data, 100 ) == 0)
    {
        cout << "BambooArmRobot::write : ERROR int sending command\n";
        
    }
    usleep(10000);
}

