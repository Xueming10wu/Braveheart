#include "bamboo_arm/BambooArmRobot.h"

int main(int argc, char *argv[])
{
    ros::init(argc, argv, "bamboo_arm_node");
    BambooArmRobot robot;
    controller_manager::ControllerManager cm(&robot);
    ros::AsyncSpinner spinner(1);
    spinner.start();

    //Control loop
    ros::Time prev_time = ros::Time::now();
    ros::Rate loop_rate(10);

    while (ros::ok())
    {
        const ros::Time time = ros::Time::now();
        const ros::Duration period = time - prev_time;
        robot.read();
        cm.update(time, period);
        robot.write();
        loop_rate.sleep();
    }

    return 0;
}