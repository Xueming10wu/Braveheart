#!/usr/bin/env python
# -*- coding: utf-8 -*-

import time
import os
import numpy as np
import cv2
import rospy
import tf
import SaveOrRead
from nav_msgs.msg import OccupancyGrid
from nav_msgs.srv import GetMap,GetMapRequest,GetMapResponse
from geometry_msgs.msg import PoseStamped,PointStamped
from braveheart_detection.msg import ObjectoryRealSizePosition


#给参数  zibar_info
class Map(object):
    '''
    地图类
    '''
    def __init__(self):
        rospy.init_node('braveheart_zibar', anonymous=False)
        self.delta = rospy.get_param("/slam_gmapping/delta", 0.05)
        print ("delta : %s"%self.delta)
        self.zibar_sub = rospy.Subscriber("/detect/real_position", ObjectoryRealSizePosition, self.callback )
        
        #监听坐标树，以方便使用tf来帮助我们计算机器人坐标变换
        self.tf_listener = tf.TransformListener()

        #创建保存目录
        SaveOrRead.mkdir("../save/saveMaps")

        #建立一个列表，存放地图点
        self.position_list = []
        self.info_list = []

        print("map_drawer")

        #定时保存
        while not rospy.is_shutdown():
            time.sleep(10)
            self.saveMap()
        
        rospy.spin()

    def __del__(self):
        pass

    def call(self):
        print("call")
        try:
            rospy.wait_for_service('/dynamic_map', 2.0)
            mapClient = rospy.ServiceProxy('/dynamic_map', GetMap())
            #此处使用的是委托服务
            res = mapClient()
            return res
        except rospy.ServiceException, e:
            print "Service call failed: %s"%e

    def callback(self, msg):
        #检查之前是否有保存过这个二维码
        #通过参数zibar_info
        zibar_info = msg.info
        data = PointStamped(msg.header, msg.position)

        #告诉tf变换 ，我需要的是这个点在"/map"下的坐标，data这个点是在摄像头坐标系下的获得的，self.object_point"base_link"下的信息
        data.header.stamp = rospy.Time()
        object_point = self.tf_listener.transformPoint("/map", data )
        print("PointStamped")
        print(data)

        position = []
        position.append(object_point.point.x)
        position.append(object_point.point.y)

        #检查之前是否存储过这个信息
        hasSave = False
        for i in range(0, len(self.info_list)):
            if zibar_info == self.info_list[i]:
                #更新到列表中
                self.position_list[i] = position
                hasSave = True
        if hasSave :
            pass
        else:
            self.position_list.append(position)
            self.info_list.append(zibar_info)

        self.saveMap()
    

    def saveMap(self):
        try:
            res = self.call()
            mapArray = np.array(res.map.data)
            cols = res.map.info.width
            rows = res.map.info.height
            mapArray =  mapArray.reshape((rows, cols))
            #print mapArray
            #print mapArray.shape
            #print type(mapArray)
            map = np.empty((rows,cols,3), dtype = np.uint8)
            #BGR
            map.fill(127)
            #数组中 未知区域的值为  -1，标记为灰色(默认色[127, 127, 127])
            #      无障碍区域的值为  0，标记为白色([255, 255, 255])
            #      有障碍区域的值为  100，标记为黑色([0, 0, 0])
            grey = np.array([127, 127, 127])
            whilt = np.array([255, 255, 255])
            black = np.array([0, 0, 0])
            red = np.array([0, 0, 255])

            
            
        except Exception,e:
            print (e)
            rospy.logerr("Can't connect service name : /dynamic_map")
            return
        
        print(" map get succeess !")
        for i in range(0, rows):
            for j in range(0, cols):
                if (mapArray[i,j] == 100):
                    map[rows-i-1,j] = black
                if (mapArray[i,j] == 0):
                    map[rows-i-1,j] = whilt
        
        #map[position[0] + rows / 2, position[1] + cols / 2] = red
        #金色目标点标记
        print(" 开始标记 !")
        print("self.info_list"),
        print(self.info_list)
        for i in range( 0 , len(self.info_list)):
            print("标记第"),
            print(i),
            print("个二维码")
            cv2.putText(map, self.info_list[i], (int(((self.position_list[i])[0] + cols / 2 + 1) / self.delta) , int((rows /2 - 1 -  self.position_list[1]) / self.delta)) , cv.FONT_HERSHEY_COMPLEX, 2.0, (200, 200, 0), 1)
        
        s = time.strftime("../save/saveMaps/%Y_%m_%d-%H:%M:%S.tiff", time.localtime(time.time()))
        print ("Saving...  "),
        print(s),
        cv2.imwrite(s, map)
        print ("Saved")


if __name__=='__main__':
    v = Map()
    
    rospy.spin()
