
"use strict";

let Size = require('./Size.js');
let ObjectoryRealSizePosition = require('./ObjectoryRealSizePosition.js');
let ObjectoryImageSizePosition = require('./ObjectoryImageSizePosition.js');

module.exports = {
  Size: Size,
  ObjectoryRealSizePosition: ObjectoryRealSizePosition,
  ObjectoryImageSizePosition: ObjectoryImageSizePosition,
};
